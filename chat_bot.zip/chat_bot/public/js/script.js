var sendBtn = document.getElementById("sendBtn");
var textbox = document.getElementById("textbox");

var user = { message: "" };
var charContainer = document.getElementById("chatContainer");

var arrayOfPossibleMessage = [
  { message: "hi", response: "hello" },
  { message: "how are you?", response: "I am fine" },
  { message: "what is your name?", response: "My name is Chatbot" },
  { message: "who created you?", response: "I am created by team UV" },
  { message:"tell me today's date",response:"today is 30th september"},
  { message:"what services you can provide",response:"I am your personalized , organization related chatbot and I can answer you according to our organization"}
];

function sendMessage(userMessage) {
  var messageElement = document.createElement("div");
  messageElement.style.textAlign = "right";
  messageElement.style.margin = "10px";
  messageElement.style.background = "lightgreen";
  messageElement.style.padding = "10px";
  messageElement.style.display = "block";
  messageElement.style.marginLeft = "500px";
  messageElement.style.borderRadius = "10px";
  messageElement.innerHTML =
    "<span> You: </span>" + "<span>" + userMessage + "</span>";
  charContainer.appendChild(messageElement);
}

function chatbotResponse(userMessage) {
  var chatbotMessage = "";
  var result = arrayOfPossibleMessage.filter((val) =>
    val.message.includes(userMessage.toLowerCase())
  );
  if (result.length > 0) {
    var response = result[0].response;
    chatbotMessage = response;
  } else {
    chatbotMessage = "Please, send another message";
  }

  var messageElement = document.createElement("div");
  messageElement.innerHTML =
    "<span> Chatbot: </span>" + "<span>" + chatbotMessage + "</span>";
  setTimeout(() => {
    messageElement.animate(
      [{ easing: "ease-in", opacity: 0.4 }, { opacity: 1 }],
      { duration: 1000 }
    );
    chatContainer.appendChild(messageElement);
    chatContainer.scrollTop = chatContainer.scrollHeight;
  }, 1000);
}

sendBtn.addEventListener("click", function (e) {
  var userMessage = textbox.value;
  if (userMessage == "") {
    alert("Please type some messages");
  } else {
    let userMessagesText = userMessage.trim();
    user.message = userMessagesText;
    textbox.value = "";
    sendMessage(userMessagesText);
    chatbotResponse(userMessagesText);
  }
});

function sendMail(){
  var params={
    name:document.getElementById("name").value,
    email : document.getElementById('email').value ,
    message:document.getElementById("message").value,
  };

const serviceID="service_q11552f";
const templateId="template_s9sc63k";

emailjs
.send(serviceID,templateID,params)
.then(
  res=>{
    document.getElementById("name").value="";
    document.getElementById("email").value="";
    document.getElementById("message").value="";
    console.log(res);
    alert("your message send sucessfully");
  }
)
.catch((err)=>console.log(err));
}